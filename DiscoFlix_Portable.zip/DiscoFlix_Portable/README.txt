DiscoFlix Welcomes You
Follow the on-screen prompts after running the DiscoFlix shortcut. 
If you have any questions, reach out to NastyNick#4212 on Discord. 