DiscoFlix
A media-requesting, Radarr-interfacing, movie-listing Discord Bot for your media server.

Please visit the GitHub for instructions and support: https://github.com/nickheyer/DiscoFlix